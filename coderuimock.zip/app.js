
const express = require('express');
const app = express();
const bodyParser = require('body-parser');
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

const eventTasks = require('./data/event_tasks.json');
const dictionaries = require('./data/dictionaries.json');
const medDRAEnglishSOC = require('./data/meddra_english_soc.json');
const medDRAChineseSOC = require('./data/meddra_chinese_soc.json');
const medDRAJapaneseSOC = require('./data/meddra_japanese_soc.json');
//const medDRAEnglishTerms = require('./data/meddra_english_terms.json');
const medDRAEnglishTermsByCode = require('./data/meddra_english_terms_by_code.json');
const policies = require('./data/policies.json');

app.use((req, res, next) => {
  console.log(`${req.method} >> ${req.path}`);
  if (req.query) {
    console.log(`\tquery=${JSON.stringify(req.query)}`);
  }
  if (req.body) {
    console.log(`\tbody=${JSON.stringify(req.body)}`);
  }

  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Expose-Headers', 'mcc-total-items');
  res.setHeader('Access-Control-Allow-Headers', 'x-requested-with,mcc-impersonate');
  res.setHeader('Cache-Control', 'max-age=0, private, must-revalidate');
  next();
});

app.listen(3000, () => {
 console.log('Server running on port 3000');
});

app.get('/apps/coder_frontier/api/coding_tasks/events', (req, res) => {
  if (!req.query['parent_uri']) {
    res.statusCode = 400;
    return res.send('missing parent uri');
  }

  res.setHeader('mcc-total-items', eventTasks.length);

  var page = req.query['page'];
  var perPage = req.query['perPage'];
  var returnedData = getPage(eventTasks, page, perPage);

  res.statusCode = 200;
  return res.send(JSON.stringify(returnedData));
});

app.get('/apps/coder_frontier/api/coding_tasks/medications', (req, res) => {
  if (!req.query['parent_uri']) {
    res.statusCode = 400;
    return res.send('missing parent uri');
  }

  res.setHeader('mcc-total-items', eventTasks.length);

  var page = req.query['page'];
  var perPage = req.query['perPage'];
  var returnedData = getPage(eventTasks, page, perPage);

  res.statusCode = 200;
  return res.send(JSON.stringify(returnedData));
});

app.get('/apps/coder_frontier/api/browser/dictionaries', (req, res) => {
  
  res.setHeader('mcc-total-items', dictionaries.length);

  var returnedData = dictionaries;

  res.statusCode = 200;
  return res.send(JSON.stringify(returnedData));
});

app.get('/apps/coder_frontier/api/browser/events/socs', (req, res) => {
  res.setHeader('mcc-total-items', dictionaries.length);

  var version = req.query['version'];
  var language = req.query['language'];

  var data = medDRAEnglishSOC;

  if (language == 'chinese') {
    data = medDRAChineseSOC;
  }
  else if(language == 'japanese') {
    data = medDRAJapaneseSOC;
  }
  

  res.statusCode = 200;
  return res.send(JSON.stringify(data));
});

app.get('/apps/coder_frontier/api/browser/events/:code/children', (req, res) => {
  var code = req.params.code;

  var children = medDRAEnglishTermsByCode[code];
  if(!children) {
    res.statusCode = 404;
    return res.send();
  }

  res.statusCode = 200;
  return res.send(JSON.stringify(children))
})

app.post('/checkmate/euresource/policies/get', (req, res) => {


  var returnedData = policies;

  res.statusCode = 200;
  return res.send(JSON.stringify(returnedData));
});

app.post('/checkmate/euresource/policies/post', (req, res) => {


  var returnedData = policies;

  res.statusCode = 200;
  return res.sendStatus(200);
});

function getPage(data, page, perPage) {
  return data.slice(data.slice(page * perPage, (page * perPage) + perPage));
};
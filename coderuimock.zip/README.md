# CoderUI Mock

Very basic nodejs app that acts as a mock for the Coder UI API. This can be used for local development when just wanting to run the react application without the backend c# application.

### Usage
To use the mock set the api url env var and then run the app via a terminal.

Start the mock api in a terminal
```
node app.js
```

in a separate terminal run the react app

```
set REACT_APP_API_URL=http:localhost:8080
npm start
```